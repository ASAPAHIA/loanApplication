package com.cg.project.exceptions;

public class InvalidCustomerDetailException extends RuntimeException{

	public InvalidCustomerDetailException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public InvalidCustomerDetailException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public InvalidCustomerDetailException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public InvalidCustomerDetailException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public InvalidCustomerDetailException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
