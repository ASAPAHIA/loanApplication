package com.cg.project.exceptions;

public class InvalidEmiException extends RuntimeException {

	public InvalidEmiException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public InvalidEmiException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public InvalidEmiException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public InvalidEmiException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public InvalidEmiException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
