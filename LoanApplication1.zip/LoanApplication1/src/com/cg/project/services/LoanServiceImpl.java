package com.cg.project.services;

import com.cg.project.Dao.LoanServiceDao;
import com.cg.project.Dao.LoanServiceDaoImpl;
import com.cg.project.beans.Customer;
import com.cg.project.beans.Loan;
import com.cg.project.exceptions.InvalidCustomerDetailException;
import com.cg.project.exceptions.InvalidEmiException;

public class LoanServiceImpl implements LoanService{
public LoanServiceDao serveDao=new LoanServiceDaoImpl();
	@Override
	public long applyLoan(Loan loan){
		return serveDao.applyLoan(loan);
	}

	@Override
	public Customer validateCustomer(Customer customer) throws InvalidCustomerDetailException {
		if(serveDao.customerEntry.get(customer.getCustId())==null){
		throw new InvalidCustomerDetailException();	
		}
		return customer;
	}

	@Override
	public long insertCust(Customer cust) throws InvalidCustomerDetailException {
		if(serveDao.customerEntry.get(cust.getCustId())==null){
			throw new InvalidCustomerDetailException();	
			}
		return serveDao.insertCust(cust);
	}

	@Override
	public double calculateEMI(double amount, int duration) throws InvalidEmiException {
		if(duration==0) {
			throw new InvalidEmiException();
		}
		double EMI=(amount*9.5*(1+9.5)*duration)/((1+9.5)*duration-1);
		return EMI;
	}

}
