package com.cg.project.services;

import com.cg.project.Dao.LoanServiceDao;
import com.cg.project.Dao.LoanServiceDaoImpl;
import com.cg.project.beans.Customer;
import com.cg.project.beans.Loan;
import com.cg.project.exceptions.InvalidCustomerDetailException;
import com.cg.project.exceptions.InvalidEmiException;

public class LoanServiceImpl implements LoanService{
public LoanServiceDao serveDao=new LoanServiceDaoImpl();
	@Override
	public long applyLoan(Loan loan){
		return serveDao.applyLoan(loan);
	}

	@Override
	public Customer validateCustomer(Customer customer) throws InvalidCustomerDetailException {
		if(customer.getCustId()==0){
		throw new InvalidCustomerDetailException();	
		}
		return customer;
	}

	@Override
	public long insertCust(Customer cust)  {
		return serveDao.insertCust(cust);	
		
	}

	@Override
	public double calculateEMI(double amount, int duration) throws InvalidEmiException {
		if(duration==0) {
			throw new InvalidEmiException();
		}
		int n=duration*12;
		double r=9.5/100;
		double EMI=amount*r*Math.pow(r+1, n)/Math.pow(r+1, n-1);
		return EMI;
	}

	@Override
	public long getLoan(Loan loan) {
		serveDao.loanEntry.put((int) loan.getLoanId(), loan);
		return loan.getLoanId();
	}

}
