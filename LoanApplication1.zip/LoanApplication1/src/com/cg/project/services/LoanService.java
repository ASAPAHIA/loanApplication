package com.cg.project.services;

import com.cg.project.beans.Customer;
import com.cg.project.beans.Loan;
import com.cg.project.exceptions.InvalidCustomerDetailException;
import com.cg.project.exceptions.InvalidEmiException;

public interface LoanService {
public long applyLoan(Loan loan);
public long getLoan(Loan loan);
public Customer validateCustomer(Customer customer) throws InvalidCustomerDetailException;
public long  insertCust(Customer cust); 
public double calculateEMI(double amount,int duration)throws InvalidEmiException;
}
