package com.cg.project.beans;

public class Customer {
private int custId;
private String custName;
private String address;
private long mobile;
private String emailId;
private Loan loan;
public Customer() {	}

public Customer(String custName, String address, String emailId) {
	super();
	this.custName = custName;
	this.address = address;
	this.emailId = emailId;
}

public Customer(String custName, String address, long mobile, String emailId, Loan loan) {
	super();
	this.custName = custName;
	this.address = address;
	this.mobile = mobile;
	this.emailId = emailId;
	this.loan = loan;
}
public Customer(int custId, String custName, String address, long mobile, String emailId, Loan loan) {
	super();
	this.custId = custId;
	this.custName = custName;
	this.address = address;
	this.mobile = mobile;
	this.emailId = emailId;
	this.loan = loan;
}
public long getCustId() {
	return custId;
}
public void setCustId(int ran) {
	this.custId = ran;
}
public String getCustName() {
	return custName;
}
public void setCustName(String custName) {
	this.custName = custName;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}
public long getMobile() {
	return mobile;
}
public void setMobile(long mobile) {
	this.mobile = mobile;
}
public String getEmailId() {
	return emailId;
}
public void setEmailId(String emailId) {
	this.emailId = emailId;
}
public Loan getLoan() {
	return loan;
}
public void setLoan(Loan loan) {
	this.loan = loan;
}
@Override
public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + ((address == null) ? 0 : address.hashCode());
	result = prime * result + (int) (custId ^ (custId >>> 32));
	result = prime * result + ((custName == null) ? 0 : custName.hashCode());
	result = prime * result + ((emailId == null) ? 0 : emailId.hashCode());
	result = prime * result + ((loan == null) ? 0 : loan.hashCode());
	result = prime * result + (int) (mobile ^ (mobile >>> 32));
	return result;
}
@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	Customer other = (Customer) obj;
	if (address == null) {
		if (other.address != null)
			return false;
	} else if (!address.equals(other.address))
		return false;
	if (custId != other.custId)
		return false;
	if (custName == null) {
		if (other.custName != null)
			return false;
	} else if (!custName.equals(other.custName))
		return false;
	if (emailId == null) {
		if (other.emailId != null)
			return false;
	} else if (!emailId.equals(other.emailId))
		return false;
	if (loan == null) {
		if (other.loan != null)
			return false;
	} else if (!loan.equals(other.loan))
		return false;
	if (mobile != other.mobile)
		return false;
	return true;
}
@Override
public String toString() {
	return "Customer [custId=" + custId + ", custName=" + custName + ", address=" + address + ", mobile=" + mobile
			+ ", emailId=" + emailId + ", loan=" + loan + "]";
}

}