package com.cg.project.Dao;

import java.util.HashMap;

import com.cg.project.beans.Customer;
import com.cg.project.beans.Loan;

public interface LoanServiceDao {
public static  HashMap<Integer,Customer>customerEntry=new HashMap<Integer, Customer>();
public static  HashMap<Integer,Loan>loanEntry=new HashMap<Integer, Loan>();

public long applyLoan(Loan loan);
public long insertCust(Customer customer);
}
