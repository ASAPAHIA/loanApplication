package com.cg.project.Dao;

import com.cg.project.beans.Customer;
import com.cg.project.beans.Loan;

public class LoanServiceDaoImpl implements LoanServiceDao {


	@Override
	public long applyLoan(Loan loan) {
long rand=(long) (Math.random()*1000);
	loan.setLoanId(rand);
	loanEntry.put((int) loan.getLoanId(), loan);
	return loan.getLoanId();	
	}
	@Override
	public long insertCust(Customer customer) {
	int ran= (int) (Math.random()*1000);
		customer.setCustId(ran);
		customerEntry.put((int) customer.getCustId(), customer);
		return customer.getCustId();
	}

}
