package com.cg.project.Dao;

import com.cg.project.beans.Customer;
import com.cg.project.beans.Loan;

public class LoanServiceDaoImpl implements LoanServiceDao {


	@Override
	public long applyLoan(Loan loan) {
long rand=(long) (Math.random()*1000);
	loan.setLoanId(rand);
	return loan.getLoanId();	
	}
	@Override
	public long insertCust(Customer customer) {
		long ran=(long) (Math.random()*1000);
		customer.setCustId(ran);
		return customer.getCustId();
	}

}
