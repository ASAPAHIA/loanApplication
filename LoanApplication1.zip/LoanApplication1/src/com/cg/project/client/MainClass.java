package com.cg.project.client;
import java.util.Scanner;
import com.cg.project.beans.Customer;
import com.cg.project.beans.Loan;
import com.cg.project.exceptions.InvalidCustomerDetailException;
import com.cg.project.exceptions.InvalidEmiException;
import com.cg.project.services.LoanService;
import com.cg.project.services.LoanServiceImpl;
public class MainClass {
	public static void main(String args[]) {
		LoanService ls=new LoanServiceImpl();
		Scanner sc=new Scanner(System.in);
		int ch;		
		System.out.println("XYZ company welcomes you");
		System.out.println("Enter 1 to register customer\nEnter 2 to exit");
		ch=sc.nextInt();
		switch(ch)
		{
		case 1:{
			try {
				System.out.println("enter customer name");
				String name=sc.next();
				System.out.println("enter customer address");
				String add=sc.next();
				System.out.println("enter customer emailId");
				String eId=sc.next();
				Customer cust1=new Customer(name, add, eId);
				ls.insertCust(cust1);
				System.out.println("information saved");
				System.out.println("your customerId="+cust1.getCustId());
				ls.validateCustomer(cust1);
				System.out.println("Do you wish to apply for loan (yes/no)");
				String choose;
				choose=sc.next();
				if(choose.equals("yes")) {
					System.out.println("enter loan amount");
					long lAmount=sc.nextInt();
					System.out.println("enter duration");
					int duration=sc.nextInt();
					Loan l1=new Loan(lAmount, cust1.getCustId(), duration);
					ls.applyLoan(l1);
					System.out.println("for loan amount"+lAmount+"and"+duration+"years");
					System.out.println("your emi is="+ls.calculateEMI(lAmount, duration));
					System.out.println("Do you want to apply for loan now?");
					String ak;
					ak=sc.next();
					if(ak.equalsIgnoreCase("yes")) {
						ls.getLoan(l1);
						System.out.println("loan request accepted"+" "+"your loan Id="+ls.applyLoan(l1));
					}
					if(ak.equalsIgnoreCase("No")) {
						System.exit(0);
					}
				}
				else {
					System.exit(0);
				}
			}catch( InvalidCustomerDetailException e) {
				System.out.println("invalid customer");
			}catch(InvalidEmiException e) {
				System.out.println("invalid emi");
			}
		}
		break;
		case 2:
			System.exit(0);
			break;
		}
	}
}

